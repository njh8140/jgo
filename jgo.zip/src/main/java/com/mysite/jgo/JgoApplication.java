package com.mysite.jgo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JgoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JgoApplication.class, args);
	}

}
