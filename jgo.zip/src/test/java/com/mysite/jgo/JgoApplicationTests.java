package com.mysite.jgo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JgoApplicationTests {

	@Test
	void contextLoads() {
	}

}
